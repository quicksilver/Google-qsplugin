int ns__getQuote(char *symbol, float *Result);
