//gsoap ns schema namespace: urn:xmethods-delayed-quotes
int ns__getQuote(char *symbol, float *Result);
