#import "dom.h"
typedef float xsd__float;
