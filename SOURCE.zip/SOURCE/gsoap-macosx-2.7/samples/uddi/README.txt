UDDI

Please note:

This is a very old-style UDDI interface. It is left as an example in the
distribution package. We will consider upgrading to UDDI v3.
