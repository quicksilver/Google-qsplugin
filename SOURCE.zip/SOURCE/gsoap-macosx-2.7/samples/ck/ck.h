//gsoap ck service name:	ck
//gsoap ck service style:	rpc
//gsoap ck service encoding:	encoded
//gsoap ck service location:	http://www.cs.fsu.edu/~engelen/ck.cgi
//gsoap ck service namespace:	http://www.cs.fsu.edu/~engelen/ck.wsdl

//gsoap ck schema  namespace:	urn:ck
int ck__demo(char **r);
