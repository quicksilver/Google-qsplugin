apache_gsoap.0.0.5.tgz		mod_gsoap module for Apache < v2.0
mod_gsoap_win_0_0_2.zip		mod_gsoap module for IIS
apache_gsoap.h			mod_gsoap module for Apache v2.0
mod_gsoap.c			mod_gsoap module for Apache v2.0
mod_gsoap.vcproj		MSVC project
