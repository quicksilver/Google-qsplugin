/*
	XMLRPCDemo.h
	XMLRPCDemo

	Created by Brent Simmons on Wed Sep 11 2002.
	Copyright (c) 2002 Brent Simmons. All rights reserved.
*/


#import <Cocoa/Cocoa.h>


@interface XMLRPCDemo : NSObject {

	IBOutlet NSTextField *numberField;
	IBOutlet NSTextField *resultField;
	}


- (IBAction) getStateName: (id) sender;


@end
