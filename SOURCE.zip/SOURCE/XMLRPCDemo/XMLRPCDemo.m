/*
	XMLRPCDemo.m
	XMLRPCDemo

	Created by Brent Simmons on Wed Sep 11 2002.
	Copyright (c) 2002 Brent Simmons. All rights reserved.
*/


/*
Note: the important header file to see is WSMethodInvocation.h.
It's part of the CoreServices framework.
*/


#import <CoreServices/CoreServices.h>
#import "XMLRPCDemo.h"


@implementation XMLRPCDemo


- (IBAction) getStateName: (id) sender {
	
	/*
	Called when the Get button is clicked.
	*/
	
	int ixState = [numberField intValue];
	NSNumber *stateNum = [NSNumber numberWithInt: ixState];
	WSMethodInvocationRef rpcCall;
	NSURL *rpcURL = [NSURL URLWithString: @"http://betty.userland.com/RPC2"];
	NSString *methodName = @"examples.getStateName";
	NSDictionary *params = [NSDictionary dictionaryWithObject: stateNum forKey: @"foo"];
	NSDictionary *result;
	
	/*First create a method invocation.*/
	
	/*First parameter is the URL to the XML-RPC web service.
	Second parameter is the name of the XML-RPC method to call.
	Third parameter is a constant specifying XML-RPC protocol.*/
	
	rpcCall = WSMethodInvocationCreate ((CFURLRef) rpcURL, (CFStringRef) methodName, kWSXMLRPCProtocol);

	/*Then set the parameters. (There's just one in this case.)*/
	
	/*First parameter is the invocation created above.
	Second parameter is a dictionary containing the parameters.
	Third parameter may be an array specifying parameter order.
	(Since there's just one parameter, NULL is passed for parameter order.)*/
	
	/*We'll deliberately cause a fault if state num is less than 1 or greater than
	50, just to demonstrate fault-handling. If state num isn't in the right
	range, we won't set an parameters at all.*/
	
	if ((ixState >= 1) && (ixState <= 50))
		WSMethodInvocationSetParameters (rpcCall, (CFDictionaryRef) params, NULL);
	
	/*Do the actual XML-RPC call and get the result.*/
	
	result = (NSDictionary *) (WSMethodInvocationInvoke (rpcCall));
	
	/*Display the result.*/
	
	if (WSMethodResultIsFault ((CFDictionaryRef) result)) /*error?*/
		[resultField setStringValue: [result objectForKey: (NSString *) kWSFaultString]];
		
	else /*no error; all's well*/
		[resultField setStringValue: [result objectForKey: (NSString *) kWSMethodInvocationResult]];		
	} /*getStateName*/


@end
